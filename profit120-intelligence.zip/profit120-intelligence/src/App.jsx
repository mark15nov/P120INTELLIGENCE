import { useEffect, useRef, useState } from 'react'
import './App.css'

/* ─── LOGO SVG ─────────────────────────────────────────────── */
function Logo({ color = '#fff', size = 140 }) {
  return (
    <svg width={size} height={size * 0.28} viewBox="0 0 500 100" fill="none">
      <text
        x="0" y="76"
        fontFamily="Inter, sans-serif"
        fontWeight="600"
        fontSize="88"
        letterSpacing="-2"
        fill={color}
      >
        Profit
      </text>
      <text
        x="268" y="76"
        fontFamily="Inter, sans-serif"
        fontWeight="700"
        fontSize="88"
        fill="#71b248"
      >
        120
      </text>
    </svg>
  )
}

/* ─── NAV ──────────────────────────────────────────────────── */
function Nav() {
  const [scrolled, setScrolled] = useState(false)
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])
  return (
    <nav className={`nav ${scrolled ? 'nav--scrolled' : ''}`}>
      <Logo size={120} />
      <div className="nav__badge">INTELLIGENCE</div>
      <a href="#contacto" className="nav__cta">Solicitar Demo</a>
    </nav>
  )
}

/* ─── HERO ─────────────────────────────────────────────────── */
function Hero() {
  return (
    <section className="hero">
      <div className="hero__grid-bg" aria-hidden="true">
        {Array.from({ length: 120 }).map((_, i) => (
          <div key={i} className="hero__grid-cell" />
        ))}
      </div>
      <div className="hero__noise" aria-hidden="true" />

      <div className="hero__content">
        <div className="hero__tag">
          <span className="hero__tag-dot" />
          IA Operativa para PYMEs
        </div>

        <h1 className="hero__headline">
          Tu empresa genera datos<br />
          <span className="hero__headline--green">todos los días.</span>
        </h1>

        <p className="hero__sub">
          ¿Te ayudan a decidir, o solo a saber<br />lo que ya ocurrió?
        </p>

        <div className="hero__actions">
          <a href="#como-funciona" className="btn btn--primary">Ver cómo funciona</a>
          <a href="#contacto" className="btn btn--ghost">Solicitar Demo →</a>
        </div>

        <div className="hero__stats">
          {[
            { num: 'CORTEX120', label: 'Motor de análisis IA' },
            { num: 'Tiempo Real', label: 'Visión de tu empresa' },
            { num: '250+', label: 'Herramientas de dirección' },
          ].map((s, i) => (
            <div key={i} className="hero__stat">
              <span className="hero__stat-num">{s.num}</span>
              <span className="hero__stat-label">{s.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="hero__visual">
        <DashboardMockup />
      </div>
    </section>
  )
}

/* ─── DASHBOARD MOCKUP ────────────────────────────────────── */
function DashboardMockup() {
  return (
    <div className="dashboard">
      <div className="dashboard__bar">
        <span className="dashboard__dot dashboard__dot--red" />
        <span className="dashboard__dot dashboard__dot--yellow" />
        <span className="dashboard__dot dashboard__dot--green" />
        <span className="dashboard__title">CORTEX120 — Dashboard</span>
      </div>
      <div className="dashboard__body">
        <div className="dashboard__kpis">
          {[
            { label: 'MARGEN NETO', val: '23.4%', trend: '+2.1%', up: true },
            { label: 'VENTAS HOY', val: '$84,200', trend: '+8.3%', up: true },
            { label: 'COSTO OPERATIVO', val: '$31,500', trend: '-4.2%', up: false },
            { label: 'ROTACIÓN INV.', val: '4.8x', trend: '+0.6x', up: true },
          ].map((k, i) => (
            <div key={i} className="kpi-card">
              <span className="kpi-card__label">{k.label}</span>
              <span className="kpi-card__val">{k.val}</span>
              <span className={`kpi-card__trend ${k.up ? 'kpi-card__trend--up' : 'kpi-card__trend--down'}`}>
                {k.up ? '↑' : '↓'} {k.trend}
              </span>
            </div>
          ))}
        </div>
        <div className="dashboard__charts">
          <MiniChart />
          <div className="dashboard__alerts">
            <span className="alerts__label">ALERTAS ACTIVAS</span>
            {[
              { msg: 'Desviación en margen — Línea A', type: 'warn' },
              { msg: 'Oportunidad detectada: Zona Norte', type: 'ok' },
              { msg: 'Inventario crítico: SKU-4421', type: 'err' },
            ].map((a, i) => (
              <div key={i} className={`alert-item alert-item--${a.type}`}>
                <span className="alert-item__dot" />
                {a.msg}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

function MiniChart() {
  const points = [20, 35, 28, 50, 45, 65, 58, 72, 68, 85, 78, 92]
  const w = 220, h = 80
  const max = Math.max(...points)
  const coords = points.map((p, i) => ({
    x: (i / (points.length - 1)) * w,
    y: h - (p / max) * h * 0.85
  }))
  const path = coords.map((c, i) => `${i === 0 ? 'M' : 'L'}${c.x},${c.y}`).join(' ')
  const area = path + ` L${w},${h} L0,${h} Z`
  return (
    <div className="mini-chart">
      <span className="mini-chart__label">VENTAS — 12 MESES</span>
      <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
        <defs>
          <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#71b248" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#71b248" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={area} fill="url(#chartGrad)" />
        <path d={path} stroke="#71b248" strokeWidth="1.5" fill="none" />
        {coords.map((c, i) => i === coords.length - 1 && (
          <circle key={i} cx={c.x} cy={c.y} r="3" fill="#71b248" />
        ))}
      </svg>
    </div>
  )
}

/* ─── PROBLEM SECTION ─────────────────────────────────────── */
function Problem() {
  return (
    <section className="problem">
      <div className="problem__inner">
        <div className="problem__left">
          <span className="section-tag">El Problema</span>
          <h2 className="problem__headline">
            No es falta de datos.<br />
            <em>Es falta de inteligencia operativa.</em>
          </h2>
        </div>
        <div className="problem__right">
          <p className="problem__body">
            Todas las empresas generan datos: ventas, inventarios, márgenes, clientes, operaciones.
            Sin embargo, la mayoría de esos datos no ayudan a decidir, <strong>solo a reportar lo que ya pasó.</strong>
          </p>
          <p className="problem__body">
            La información crítica termina dispersa entre sistemas y hojas de Excel. Muchas decisiones se toman
            con información incompleta, los problemas se detectan demasiado tarde y las oportunidades pasan desapercibidas.
          </p>
          <div className="problem__pillars">
            {[
              { icon: '⚠', text: 'Decisiones con información incompleta' },
              { icon: '⏱', text: 'Problemas detectados demasiado tarde' },
              { icon: '📉', text: 'Oportunidades que pasan desapercibidas' },
            ].map((p, i) => (
              <div key={i} className="pillar">
                <span className="pillar__icon">{p.icon}</span>
                <span className="pillar__text">{p.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ─── CORTEX SECTION ──────────────────────────────────────── */
function Cortex() {
  const nodes = [
    { label: 'VENTAS', angle: -120 },
    { label: 'LEADS', angle: -80 },
    { label: 'MARKETING', angle: -40 },
    { label: 'LOGÍSTICA', angle: 20 },
    { label: 'CONTABILIDAD', angle: 60 },
    { label: 'INVENTARIOS', angle: 100 },
    { label: 'FINANZAS', angle: 140 },
    { label: 'RRHH', angle: 175 },
  ]
  const r = 160
  return (
    <section className="cortex" id="como-funciona">
      <div className="cortex__inner">
        <div className="cortex__text">
          <span className="section-tag">La Solución</span>
          <h2 className="cortex__headline">
            Conoce<br />
            <span className="green-text">CORTEX120</span>
          </h2>
          <p className="cortex__body">
            Nuestro motor de inteligencia empresarial impulsado por los cerebros de IA más avanzados del mundo.
            Integra todos los sistemas de tu empresa y construye dashboards personalizados que detectan desviaciones,
            identifican oportunidades y generan alertas clave — ofreciéndote una visión clara en tiempo real.
          </p>
          <div className="cortex__features">
            {[
              'Integración con ERP, CRM, contabilidad, inventarios',
              'Dashboards construidos a la medida de tu operación',
              'Alertas inteligentes antes de que impacten tu negocio',
              'Comunicación directa con tu IA personalizada',
            ].map((f, i) => (
              <div key={i} className="cortex__feature">
                <span className="cortex__check">✓</span>
                {f}
              </div>
            ))}
          </div>
        </div>

        <div className="cortex__diagram">
          <svg viewBox="-200 -200 400 400" className="cortex__svg">
            {/* Connection lines */}
            {nodes.map((n, i) => {
              const rad = (n.angle * Math.PI) / 180
              const x = Math.cos(rad) * r
              const y = Math.sin(rad) * r
              return (
                <line
                  key={i}
                  x1="0" y1="0"
                  x2={x} y2={y}
                  stroke="#71b248"
                  strokeWidth="0.8"
                  strokeOpacity="0.4"
                  strokeDasharray="4 3"
                />
              )
            })}
            {/* Center node */}
            <circle cx="0" cy="0" r="50" fill="#1f2225" stroke="#71b248" strokeWidth="1.5" />
            <circle cx="0" cy="0" r="44" fill="#3c4045" fillOpacity="0.4" />
            <text textAnchor="middle" y="-8" fill="#71b248" fontSize="10" fontFamily="Inter" fontWeight="700">CORTEX</text>
            <text textAnchor="middle" y="8" fill="#71b248" fontSize="14" fontFamily="Inter" fontWeight="800">120</text>

            {/* Outer nodes */}
            {nodes.map((n, i) => {
              const rad = (n.angle * Math.PI) / 180
              const x = Math.cos(rad) * r
              const y = Math.sin(rad) * r
              return (
                <g key={i}>
                  <circle cx={x} cy={y} r="28" fill="#1f2225" stroke="#3c4045" strokeWidth="1" />
                  <circle cx={x} cy={y} r="4" fill="#71b248" />
                  <text
                    x={x} y={y + 20}
                    textAnchor="middle"
                    fill="#8a8f96"
                    fontSize="7"
                    fontFamily="Inter"
                    fontWeight="600"
                    letterSpacing="0.5"
                  >
                    {n.label}
                  </text>
                </g>
              )
            })}

            {/* Bottom node - TU EMPRESA */}
            <rect x="-42" y="155" width="84" height="34" rx="6" fill="#71b248" />
            <text textAnchor="middle" y="167" fill="#1f2225" fontSize="7" fontFamily="Inter" fontWeight="700">TU</text>
            <text textAnchor="middle" y="178" fill="#1f2225" fontSize="7" fontFamily="Inter" fontWeight="700">EMPRESA</text>
            <line x1="0" y1="50" x2="0" y2="155" stroke="#71b248" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
    </section>
  )
}

/* ─── HOW IT WORKS ────────────────────────────────────────── */
function HowItWorks() {
  const steps = [
    {
      num: '01',
      title: 'Integramos tus datos',
      desc: 'Conectamos las principales fuentes de información de tu empresa — ERP, CRM, contabilidad, inventarios, ventas, bases de datos — para crear una capa unificada de datos. A partir de ahí, diseñamos dashboards estratégicos completamente personalizados para tu operación.',
      sources: ['ERP', 'CRM', 'Contabilidad', 'Inventarios', 'Ventas', 'RRHH']
    },
    {
      num: '02',
      title: 'CORTEX120 lo analiza',
      desc: 'Nuestro motor de inteligencia empresarial procesa la información de tu negocio en tiempo real para identificar patrones, detectar desviaciones y revelar riesgos u oportunidades que normalmente quedan ocultos entre grandes volúmenes de datos.',
      sources: ['Patrones', 'Desviaciones', 'Riesgos', 'Oportunidades']
    },
    {
      num: '03',
      title: 'Obtienes claridad estratégica',
      desc: 'Recibe KPIs, gráficas y alertas inteligentes que te permiten visualizar lo que realmente está ocurriendo en tu empresa — antes de que los problemas impacten tu operación o rentabilidad. Tú y todo tu equipo se pueden comunicar con esta IA personalizada.',
      sources: ['KPIs en vivo', 'Alertas', 'Reportes', 'Chat IA']
    },
  ]

  return (
    <section className="how">
      <div className="how__inner">
        <div className="how__header">
          <span className="section-tag">Cómo funciona</span>
          <h2 className="how__headline">
            De datos dispersos a<br />
            <span className="green-text">decisiones claras</span>
          </h2>
        </div>
        <div className="how__steps">
          {steps.map((s, i) => (
            <div key={i} className="step">
              <div className="step__num">{s.num}</div>
              <div className="step__content">
                <h3 className="step__title">{s.title}</h3>
                <p className="step__desc">{s.desc}</p>
                <div className="step__tags">
                  {s.sources.map((src, j) => (
                    <span key={j} className="step__tag">{src}</span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ─── PLATFORM CALLOUT ────────────────────────────────────── */
function Platform() {
  return (
    <section className="platform">
      <div className="platform__inner">
        <div className="platform__card">
          <div className="platform__badge">Ecosistema completo</div>
          <h2 className="platform__headline">
            Más que inteligencia.<br />
            <span className="green-text">Una plataforma completa.</span>
          </h2>
          <p className="platform__body">
            Además de Intelligence, puedes homologar toda tu información con nuestra plataforma de soluciones empresariales
            <strong> profit120.com</strong>, donde encontrarás más de 250 herramientas de dirección empresarial
            automatizadas, entrenamientos, cursos y networking a nivel LATAM.
          </p>
          <div className="platform__items">
            {[
              { icon: '🧠', title: '250+ Herramientas', sub: 'De dirección empresarial automatizadas' },
              { icon: '🎓', title: 'Entrenamientos y Cursos', sub: 'Formación práctica y aplicable' },
              { icon: '🌐', title: 'Networking LATAM', sub: 'Conecta con empresarios de toda la región' },
            ].map((item, i) => (
              <div key={i} className="platform__item">
                <span className="platform__item-icon">{item.icon}</span>
                <div>
                  <strong>{item.title}</strong>
                  <p>{item.sub}</p>
                </div>
              </div>
            ))}
          </div>
          <a href="https://profit120.com" target="_blank" rel="noopener noreferrer" className="btn btn--primary">
            Explorar profit120.com →
          </a>
        </div>

        <div className="platform__quote">
          <blockquote>
            "En un entorno donde la velocidad de decisión define a los líderes, las empresas que convierten datos en inteligencia son las que toman ventaja."
          </blockquote>
          <div className="platform__quote-sig">
            <span className="platform__quote-line" />
            <span>Profit120 Intelligence</span>
          </div>
        </div>
      </div>
    </section>
  )
}

/* ─── CTA SECTION ─────────────────────────────────────────── */
function CTA() {
  return (
    <section className="cta" id="contacto">
      <div className="cta__bg" aria-hidden="true" />
      <div className="cta__inner">
        <span className="section-tag section-tag--light">La claridad para dirigir mejor</span>
        <h2 className="cta__headline">
          Cuando la información es clara,<br />
          <span className="green-text">las decisiones son mejores.</span>
        </h2>
        <p className="cta__sub">
          El futuro deja de ser una sorpresa.
        </p>
        <div className="cta__actions">
          <a href="mailto:info@profit120.com" className="btn btn--primary btn--lg">Solicitar Demo</a>
          <a href="https://profit120.com/intelligence" target="_blank" rel="noopener noreferrer" className="btn btn--ghost btn--lg">
            Conocer más →
          </a>
        </div>
        <p className="cta__contact">
          ¿Preguntas? Escríbenos a <a href="mailto:info@profit120.com">info@profit120.com</a>
        </p>
      </div>
    </section>
  )
}

/* ─── FOOTER ──────────────────────────────────────────────── */
function Footer() {
  return (
    <footer className="footer">
      <div className="footer__inner">
        <div className="footer__brand">
          <Logo size={120} />
          <span className="footer__sub">INTELLIGENCE</span>
          <p className="footer__tagline">La primera plataforma de IA especializada en PYMEs</p>
        </div>
        <div className="footer__links">
          <a href="#como-funciona">Cómo funciona</a>
          <a href="https://profit120.com" target="_blank" rel="noopener noreferrer">profit120.com</a>
          <a href="mailto:info@profit120.com">Contacto</a>
        </div>
        <div className="footer__copy">
          © {new Date().getFullYear()} Profit120. Todos los derechos reservados.
        </div>
      </div>
    </footer>
  )
}

/* ─── APP ─────────────────────────────────────────────────── */
export default function App() {
  return (
    <>
      <Nav />
      <Hero />
      <Problem />
      <Cortex />
      <HowItWorks />
      <Platform />
      <CTA />
      <Footer />
    </>
  )
}
